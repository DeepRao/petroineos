1) Unit tested the interface to power service. Used NSubstitute and FluentAssertions along with nunit
2) Used Nlog for logging
