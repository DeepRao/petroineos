﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using NSubstitute;
using NUnit.Framework;
using Services;

namespace TradeInterface.Tests
{
    [TestFixture]
    public class TradesTests
    {
        private readonly IPowerService powerService = Substitute.For<IPowerService>();
        private PowerTrade firstTrade;
        private PowerTrade secondTrade;
        private Trades trades;

        public TradesTests()
        {
            CreateFirstTrade();
            CreateSecondTrade();
            trades = new Trades(this.powerService);
        }

        [Test]
        public void InterfaceShouldGetCorrectData()
        {
            DateTime today = DateTime.Today;
            
            powerService.GetTrades(today).Returns(TradeAndPeriod);
            var data = trades.GetVolumes();
            data["23:00"].Should().Be(firstTrade.Periods[0].Volume + secondTrade.Periods[0].Volume);
            data["00:00"].Should().Be(firstTrade.Periods[1].Volume + secondTrade.Periods[1].Volume);
            data["01:00"].Should().Be(firstTrade.Periods[2].Volume + secondTrade.Periods[2].Volume);
            data["02:00"].Should().Be(firstTrade.Periods[3].Volume + secondTrade.Periods[3].Volume);
            data["03:00"].Should().Be(firstTrade.Periods[4].Volume + secondTrade.Periods[4].Volume);
            data["04:00"].Should().Be(firstTrade.Periods[5].Volume + secondTrade.Periods[5].Volume);
            data["05:00"].Should().Be(firstTrade.Periods[6].Volume + secondTrade.Periods[6].Volume);
            data["06:00"].Should().Be(firstTrade.Periods[7].Volume + secondTrade.Periods[7].Volume);
            data["07:00"].Should().Be(firstTrade.Periods[8].Volume + secondTrade.Periods[8].Volume);
            data["08:00"].Should().Be(firstTrade.Periods[9].Volume + secondTrade.Periods[9].Volume);
            data["09:00"].Should().Be(firstTrade.Periods[10].Volume + secondTrade.Periods[10].Volume);
            data["10:00"].Should().Be(firstTrade.Periods[11].Volume + secondTrade.Periods[11].Volume);
            data["11:00"].Should().Be(firstTrade.Periods[12].Volume + secondTrade.Periods[12].Volume);
            data["12:00"].Should().Be(firstTrade.Periods[13].Volume + secondTrade.Periods[13].Volume);
            data["13:00"].Should().Be(firstTrade.Periods[14].Volume + secondTrade.Periods[14].Volume);
            data["14:00"].Should().Be(firstTrade.Periods[15].Volume + secondTrade.Periods[15].Volume);
            data["15:00"].Should().Be(firstTrade.Periods[16].Volume + secondTrade.Periods[16].Volume);
            data["16:00"].Should().Be(firstTrade.Periods[17].Volume + secondTrade.Periods[17].Volume);
            data["17:00"].Should().Be(firstTrade.Periods[18].Volume + secondTrade.Periods[18].Volume);
            data["18:00"].Should().Be(firstTrade.Periods[19].Volume + secondTrade.Periods[19].Volume);
            data["19:00"].Should().Be(firstTrade.Periods[20].Volume + secondTrade.Periods[20].Volume);
            data["20:00"].Should().Be(firstTrade.Periods[21].Volume + secondTrade.Periods[21].Volume);
            data["21:00"].Should().Be(firstTrade.Periods[22].Volume + secondTrade.Periods[22].Volume);
            data["22:00"].Should().Be(firstTrade.Periods[23].Volume + secondTrade.Periods[23].Volume);
        }

        private List<PowerTrade> TradeAndPeriod => new List<PowerTrade>()
        {
            firstTrade, secondTrade
        };

        private void CreateFirstTrade()
        {
            firstTrade = PowerTrade.Create(DateTime.Today, 24);

            for (int i = 0; i < 24; i++)
            {
                firstTrade.Periods[i].Volume = i + 1;
            }
        }

        private void CreateSecondTrade()
        {
            secondTrade = PowerTrade.Create(DateTime.Today, 24);

            for (int i = 0; i < 24; i++)
            {
                secondTrade.Periods[i].Volume = i * -2;
            }
        }
    }
}
