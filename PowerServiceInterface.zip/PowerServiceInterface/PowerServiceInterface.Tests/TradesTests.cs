﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using NSubstitute.Core;
using NSubstitute.Exceptions;
using Services;

namespace PowerServiceInterface.Tests
{
    [TestClass]
    public class TradesTests
    {
        private readonly IPowerService powerService = Substitute.For<IPowerService>();
        private PowerTrade firstPeriod;
        private PowerTrade secondPeriod;
        private Trades trades;

        [TestInitialize]
        public void Initialise()
        {
            firstPeriod = PowerTrade.Create(DateTime.Today, 24);
            secondPeriod = PowerTrade.Create(DateTime.Today, 24);
            trades = new Trades(this.powerService);
        }

        [TestMethod]
        public void InterfaceShouldGetCorrectData()
        {
            DateTime today = DateTime.Today;
            powerService.GetTrades(today).Returns(TradeAndPeriod);
            var data = trades.GetTimeAndVolume();
            data[1].Should().Be(firstPeriod.Periods[1].Volume + secondPeriod.Periods[1].Volume);
        }

        private List<PowerTrade> TradeAndPeriod => new List<PowerTrade>()
        {
            firstPeriod, secondPeriod
        };
    }
}
