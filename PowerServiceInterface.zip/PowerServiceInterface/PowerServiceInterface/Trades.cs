﻿using System;
using System.Collections.Generic;
using System.Linq;
using Services;
using NLog;

namespace TradeInterface
{
    public class Trades
    {
        private readonly IPowerService powerService;
        private  Logger logger = LogManager.GetCurrentClassLogger();

        public Trades(IPowerService powerService)
        {
            this.powerService = powerService;
        }

        public Dictionary<string, double> GetVolumes()
        {
            try
            {
                var data = this.powerService.GetTrades(DateTime.Today);
                logger.Debug("PowerService returned {0} trades", data.Count());
                var trades = new Dictionary<string, double>();
                foreach (var powerTrade in data)
                {
                    for (var i = 0; i < 24; i++)
                    {
                        var time = ConvertIndexToTime(i);
                        if (trades.ContainsKey(time))
                        {
                            trades[time] += powerTrade.Periods[i].Volume;
                        }
                        else
                        {
                            trades.Add(time, powerTrade.Periods[i].Volume);
                        }
                    }
                }
                return trades;
            }
            catch (Exception e)
            {
                logger.Error(e);
                throw;
            }
        }

        private string ConvertIndexToTime(int index)
        {
            switch (index)
            {
                case 0:
                    return "23:00";
                case 1:
                    return "00:00";
                case 2:
                    return "01:00";
                case 3:
                    return "02:00";
                case 4:
                    return "03:00";
                case 5:
                    return "04:00";
                case 6:
                    return "05:00";
                case 7:
                    return "06:00";
                case 8:
                    return "07:00";
                case 9:
                    return "08:00";
                case 10:
                    return "09:00";
                case 11:
                    return "10:00";
                case 12:
                    return "11:00";
                case 13:
                    return "12:00";
                case 14:
                    return "13:00";
                case 15:
                    return "14:00";
                case 16:
                    return "15:00";
                case 17:
                    return "16:00";
                case 18:
                    return "17:00";
                case 19:
                    return "18:00";
                case 20:
                    return "19:00";
                case 21:
                    return "20:00";
                case 22:
                    return "21:00";
                case 23:
                    return "22:00";
            }

            return string.Empty;
        }


    }
}
