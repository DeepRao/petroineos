﻿using System;
using System.Configuration;
using System.ServiceProcess;
using System.Timers;
using NLog;
using Services;
using TradeInterface;
using TradeVolumeService.Utilities;

namespace TradeVolumeService
{
    public partial class Service1 : ServiceBase
    {
        private Trades trades;
        private Timer timer;
        private Logger logger = LogManager.GetCurrentClassLogger();

        public Service1()
        {
            InitializeComponent();
            this.trades = new Trades(new PowerService());
            this.timer = new Timer();
        }

        public void RunAsConsole(string[] args)
        {
            OnStart(args);
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
            OnStop();
        }

        protected override void OnStart(string[] args)
        {
            RunOnInterval();
            GetTradeVolumes();
        }

        private void GetTradeVolumes()
        {
            TradeVolumeDictionaryToCsvConverter.WriteToCsv(this.trades.GetVolumes(), ConfigurationManager.AppSettings["OutputPath"]);
        }

        private void RunOnInterval()
        {
            var interval =  Convert.ToInt32(ConfigurationManager.AppSettings["IntervalInMinutes"]);
            timer.Elapsed += Timer_Elapsed;
            timer.Interval = interval * 60 * 1000;
            timer.Enabled = true;
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            logger.Info("Getting trades");
            GetTradeVolumes();
        }

        protected override void OnStop()
        {
        }
    }
}
