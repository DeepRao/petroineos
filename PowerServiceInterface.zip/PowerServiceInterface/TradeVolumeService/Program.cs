﻿using System;
using System.ServiceProcess;

namespace TradeVolumeService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            Service1 service1 = new Service1();

            if (Environment.UserInteractive)
            {
                service1.RunAsConsole(args);
            }
            else
            {
                var servicesToRun = new ServiceBase[] { service1 };
                ServiceBase.Run(servicesToRun);
            }
        }
    }
}
