﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NLog;

namespace TradeVolumeService.Utilities
{
    public static class TradeVolumeDictionaryToCsvConverter
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public static void WriteToCsv(Dictionary<string, double> tradeVolumes, string pathToCsv)
        {
            var csv = string.Join(",", new[] {"Local Time", "Volume"});
            csv += Environment.NewLine;
            csv += string.Join(
                Environment.NewLine,
                tradeVolumes.Select(d => d.Key + "," + d.Value + ",")
            );
            var fileName = string.Format(pathToCsv, DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.ToString("HHmm"));
            logger.Info("Writing to csv file {0}", fileName);
            File.WriteAllText(fileName, csv);
        }
    }
}
